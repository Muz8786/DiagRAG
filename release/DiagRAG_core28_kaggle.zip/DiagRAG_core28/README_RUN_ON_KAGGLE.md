# DiagRAG v4: how to run the Kaggle notebook

This zip holds one Kaggle notebook (`DiagRAG_v4_kaggle.ipynb`) and everything needed to check it: the code it runs, every judged run it is compared with, the benchmark, the docs, and a verifier.

## Run it (about 2 h 10 min on a free T4)

1. Sign in at kaggle.com. Internet and GPU need a phone-verified account.
2. **Create → New Notebook → File → Import Notebook**, and upload `DiagRAG_v4_kaggle.ipynb` from this zip.
3. In the right panel set **Accelerator: GPU T4 x1** and **Internet: On**.
4. Press **Run All**. To keep the outputs, use **Save Version → Save & Run All (Commit)** instead. The notebook needs no dataset, no API key and no secret. It downloads its data and checks the exact bytes and SHA-256 of each file before using it.
5. Results appear in `/kaggle/working/diagrag_out/`. Read `VERDICT.json` first, then `REPORT.md`, then `GPU_ANALYSIS.json`. The last cell prints the headline numbers and the code hash.
6. If the session stops, run the notebook again. It resumes from `diagrag_out/checkpoint.pkl`. To resume in a new session, attach the earlier version's output as an input.

The Kaggle free GPU quota is about 30 hours per week, so one run fits easily.

## What the run reproduces

The judged run with the same settings (seed 48, GPU T4, bge-reranker-large) is in `kaggle/judged_gpu_v4_seed48/`. Its result was:

| | Result |
|---|---|
| Verdict | **NOT_ADOPTED**: 26 of 28 detectors pass (27 needed), 27 of 28 repairs pass (24 needed) |
| Failed or thin faults | Q03 (detector and repair), C2 (detector), R26 (too few positives) |
| Closed loop | L1 do-no-harm PASS (0.0% clean loss), L2 closure PASS (0.866), **U1 unseen-fault closure FAIL (0.456, bar 0.50)**, N1 natural traffic PASS (+2.18 points, 95% CI 1.27 to 3.16) |
| Pre-registered GPU analysis | D1 PASS, D2 PASS (marginal), D3 FAIL |

A new run will not match to the last digit. GPU kernels are not fully deterministic, and the gates sit near their thresholds for some faults (Q03's detector failed in 3 of the 7 judged runs). A different outcome on the 27-detector gate is possible, and either outcome is a valid result to report.

The earlier v3 GPU run (seed 46, `kaggle/judged_gpu_v3_seed46/`) was ADOPTED with 27 of 28. The notebook ships v4 because v4 was the frozen flagship before either result was known. It was not chosen after seeing which run passed.

## What was tested

- The notebook file itself was run end to end on Kaggle (CPU, tiny settings, 16 Nov 2026). All five data files passed their size and SHA-256 checks, the code hash recorded in `JUDGED_PROTOCOL.json` equalled the frozen v4 hash, and the run stopped cleanly at its time budget with no error.
- The full 2 h 10 min GPU run (seed 48) was executed through a launcher that fetched the same `diagrag_v4.py` from a pinned commit and set the same settings. The notebook file in this zip has not itself been run for the full 2 h, so a first full run could still hit a Kaggle-side problem such as a session limit. If that happens, run it again to resume.

## What is in this zip

| Path | What it is |
|---|---|
| `DiagRAG_v4_kaggle.ipynb` | the Kaggle notebook. It embeds the frozen `diagrag_v4.py`, `natural_exclusions_v2.json` and the pre-registered analysis script, each checked by SHA-256 |
| `verify.py`, `CHECKSUMS.sha256` | run `python verify.py` to check every file and that each judged run's recorded code hash equals the code shipped here. The one exception is `judged_cpu_run_seed42`, which was produced by an earlier v1 file that is not shipped |
| `kaggle/` | all notebooks and `.py` sources (v1 to v4, port, port2, LangChain v1 and v2), `build_notebook.py`, `build_final_notebook.py`, `run_local.sh`, and the judged-run folders (`judged_*`, each with its protocol, verdict, tables and the episode file) |
| `bench/` | DiagRAG-Bench v1.0 (public dev episodes, unlabelled test episodes, scorer, datasheet) and `llm_baselines.py`. The private test labels are not included |
| `docs/` | `ROADMAP_V3.md` (every gate and result, pass or fail), `LLM_BASELINES_RESULTS.md`, `EVIDENCE_AND_NOVELTY_REPORT.md`, `IDENTIFIABILITY.md`, `CORE28_FAULTS.md`, `CROSSWALK_CATALOGUE.md`, `NEXT_SESSION_HANDOFF.md`, and the pre-registrations in `docs/evidence/` |
| `data/`, `NOTICE.md`, `paper/` | data manifest and links, third-party licences, the paper outline |

## What the numbers can and cannot support

- The 28 faults are injected by the same authors who wrote the detectors and repairs. The natural-traffic arms use real queries that were never examined while building the system.
- Every judged run was frozen (code hash and gates) before it produced results, and failures are reported with the same prominence as passes.
- Not shown: unseen-fault closure at 0.50, a diagnosis advantage over a diagnosis-free stack on accuracy (D3 fails twice), repair of natural misspellings (it harms), and non-inferiority to a CRAG-style LLM repair (inconclusive).
- The LLM baselines are not full RAGLog and not the CRAG paper. They are free-tier models given one zero-shot prompt.

## Keys and safety

The notebook needs no key. The LLM baseline script (`bench/llm_baselines.py`) reads `GROQ_API_KEY` and `GEMINI_API_KEYS` from environment variables. Never write keys into a file or a notebook cell, and never commit them.

## Disclosure

The code and documents in this project were written by Claude (Anthropic), with the repository owner directing the work. Say so in any paper or release.
