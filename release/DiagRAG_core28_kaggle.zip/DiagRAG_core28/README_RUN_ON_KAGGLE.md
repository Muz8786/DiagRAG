# DiagRAG: how to run the Kaggle notebooks

This zip holds two Kaggle notebooks and everything needed to check them:

| Notebook | State |
|---|---|
| `DiagRAG_v4_kaggle.ipynb` | the **judged** flagship (GPU seed 48, NOT_ADOPTED: 26/28 detectors). Reruns reproduce the judged configuration |
| `DiagRAG_v5_kaggle.ipynb` | the **pre-registered next run** (seed 49, `docs/evidence/v5_protocol.md`). Code frozen, **not yet executed**. The protocol allows exactly one judged run, so do not change the seed to look for a different verdict |

## Run it (v4: about 2 h 10 min on a free T4; v5: an estimate of 3 to 5 hours, not measured)

1. Sign in at kaggle.com. Internet and GPU need a phone-verified account.
2. **Create → New Notebook → File → Import Notebook**, and upload `DiagRAG_v4_kaggle.ipynb` or `DiagRAG_v5_kaggle.ipynb` from this zip.
3. In the right panel set **Accelerator: GPU T4 x1** and **Internet: On**.
4. Press **Run All**. To keep the outputs, use **Save Version → Save & Run All (Commit)** instead. The notebook needs no dataset, no API key and no secret. It downloads its data and checks the exact bytes and SHA-256 of each file before using it.
5. Results appear in `/kaggle/working/diagrag_out/`. Read `VERDICT.json` first, then `REPORT.md`, then `GPU_ANALYSIS.json`. The last cell prints the headline numbers and the code hash.
6. If the session stops, run the notebook again. It resumes from `diagrag_out/checkpoint.pkl`. To resume in a new session, attach the earlier version's output as an input.

The Kaggle free GPU quota is about 30 hours per week, so one run fits easily.

## What the run reproduces

The judged run with the same settings (seed 48, GPU T4, bge-reranker-large) is in `kaggle/judged_gpu_v4_seed48/`. Its result was:

| | Result |
|---|---|
| Verdict | **NOT_ADOPTED**: 26 of 28 detectors pass (27 needed), 27 of 28 repairs pass (24 needed) |
| Failed or thin faults | Q03 (detector and repair), C2 (detector), R26 (too few positives) |
| Closed loop | L1 do-no-harm PASS (0.0% clean loss), L2 closure PASS (0.866), **U1 unseen-fault closure FAIL (0.456, bar 0.50)**, N1 natural traffic PASS (+2.18 points, 95% CI 1.27 to 3.16) |
| Pre-registered GPU analysis | D1 PASS, D2 PASS (marginal), D3 FAIL |

A new run will not match to the last digit. GPU kernels are not fully deterministic, and the gates sit near their thresholds for some faults (Q03's detector failed in 3 of the 7 judged runs). A different outcome on the 27-detector gate is possible, and either outcome is a valid result to report.

The earlier v3 GPU run (seed 46, `kaggle/judged_gpu_v3_seed46/`) was ADOPTED with 27 of 28. The notebook ships v4 because v4 was the frozen flagship before either result was known. It was not chosen after seeing which run passed.

## What was tested

- The v4 notebook file was run end to end on Kaggle (CPU, tiny settings, 16 Nov 2026): all five data files passed their size and SHA-256 checks, the recorded code hash equalled the frozen hash, and it stopped cleanly at its time budget. The full 2 h 10 min GPU run was executed through a launcher that fetched the same `diagrag_v4.py` from a pinned commit.
- The v5 code ran end to end on CPU with tiny settings (exit 0; the protocol file records its hash, the 50-positive floor, the deployed-config switch and the library versions). The v5 notebook file embeds exactly the hash frozen in the protocol (`verify.py` checks it) but **has not been run on Kaggle**, and the v5 pipeline has not run at full scale on a GPU. A first full run could still hit a Kaggle-side problem. If it stops, run it again to resume.
- `python kaggle/reproduce_tables.py kaggle/judged_cpu_run_v4_seed47` re-fits every detector from the shipped episodes: 31 of 31 reproduce. The same check on the Kaggle GPU run (seed 48) reproduces 27 of 31 within 0.005, because of a library difference (see `docs/ROADMAP_V4.md` and `docs/evidence/v5_protocol.md` amendment B5).

## What is in this zip

| Path | What it is |
|---|---|
| `DiagRAG_v4_kaggle.ipynb`, `DiagRAG_v5_kaggle.ipynb` | the Kaggle notebooks. Each embeds its frozen script (`diagrag_v4.py` or `diagrag_v5.py`), `natural_exclusions_v2.json` and the pre-registered analysis script, each checked by SHA-256 |
| `verify.py`, `CHECKSUMS.sha256` | run `python verify.py` to check every file and that each judged run's recorded code hash equals the code shipped here. The one exception is `judged_cpu_run_seed42`, which was produced by an earlier v1 file that is not shipped |
| `kaggle/` | all notebooks and `.py` sources (v1 to v4, port, port2, LangChain v1 and v2), `build_notebook.py`, `build_final_notebook.py`, `run_local.sh`, and the judged-run folders (`judged_*`, each with its protocol, verdict, tables and the episode file) |
| `bench/` | DiagRAG-Bench v1.0 (public dev episodes, unlabelled test episodes, scorer, datasheet, `QUICKSTART.md`, `verify_release.py`) and `llm_baselines.py`. The private test labels are not included |
| `docs/` | `ROADMAP_V3.md` and `ROADMAP_V4.md` (every gate and result, pass or fail), `REPRODUCE.md`, `REPLICATION_INVITATION.md` (a draft, not sent), `LLM_BASELINES_RESULTS.md`, `EVIDENCE_AND_NOVELTY_REPORT.md`, `IDENTIFIABILITY.md`, `CORE28_FAULTS.md`, `CROSSWALK_CATALOGUE.md`, `NEXT_SESSION_HANDOFF.md`, and the pre-registrations in `docs/evidence/` |
| `data/`, `NOTICE.md`, `paper/` | data manifest and links, third-party licences, the paper outline |

## What the numbers can and cannot support

- The 28 faults are injected by the same authors who wrote the detectors and repairs. The natural-traffic arms use real queries that were never examined while building the system.
- Every judged run was frozen (code hash and gates) before it produced results, and failures are reported with the same prominence as passes.
- Not shown: unseen-fault closure at 0.50, a diagnosis advantage over a diagnosis-free stack on accuracy (D3 fails twice), repair of natural misspellings (it harms), and non-inferiority to a CRAG-style LLM repair (inconclusive).
- The LLM baselines are not full RAGLog and not the CRAG paper. They are free-tier models given one zero-shot prompt.

## Keys and safety

The notebook needs no key. The LLM baseline script (`bench/llm_baselines.py`) reads `GROQ_API_KEY` and `GEMINI_API_KEYS` from environment variables. Never write keys into a file or a notebook cell, and never commit them.

## Disclosure

The code and documents in this project were written by Claude (Anthropic), with the repository owner directing the work. Say so in any paper or release.
