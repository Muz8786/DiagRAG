"""Integrity check for the DiagRAG zip. Run:  python verify.py
1) every file listed in CHECKSUMS.sha256 has the recorded SHA-256;
2) every judged run's JUDGED/PORT/LC protocol records the SHA-256 of the .py file that produced it (older seed-42 run: code not shipped);
3) DiagRAG_v4_kaggle.ipynb embeds the frozen v4 file (hash re-computed after decoding)."""
import ast, base64, glob, gzip, hashlib, json, os, sys
here = os.path.dirname(os.path.abspath(__file__)); bad = 0
sha = lambda p: hashlib.sha256(open(p, 'rb').read()).hexdigest()
for line in open(os.path.join(here, 'CHECKSUMS.sha256'), encoding='utf-8'):
    h, p = line.rstrip('\n').split('  ', 1)
    if not os.path.exists(os.path.join(here, p)) or sha(os.path.join(here, p)) != h: print('MISMATCH', p); bad += 1
print('checksums checked')
PAIRS = {'judged_cpu_run_seed43': 'diagrag_core28.py', 'judged_cpu_run_v2_seed44': 'diagrag_v2.py', 'judged_cpu_run_v3_seed45': 'diagrag_v3.py',
         'judged_gpu_v3_seed46': 'diagrag_v3.py', 'judged_cpu_run_v4_seed47': 'diagrag_v4.py', 'judged_gpu_v4_seed48': 'diagrag_v4.py',
         'judged_port_scifact': 'diagrag_port.py', 'judged_port2_scifact': 'diagrag_port2.py', 'judged_port2_fiqa': 'diagrag_port2.py',
         'judged_langchain_scifact': 'diagrag_langchain.py', 'judged_langchain_v2_scifact': 'diagrag_langchain2.py'}
for folder, py in PAIRS.items():
    prot = glob.glob(os.path.join(here, 'kaggle', folder, '*PROTOCOL.json'))
    want = json.load(open(prot[0]))['code_sha256']; have = sha(os.path.join(here, 'kaggle', py))
    ok = want == have; bad += (not ok); print(('ok      ' if ok else 'MISMATCH'), folder, '<-', py)
nb = json.load(open(os.path.join(here, 'DiagRAG_v4_kaggle.ipynb'))); src = '\n'.join(''.join(c['source']) for c in nb['cells'] if c['cell_type'] == 'code')
ns = {}; exec(src.split('# 3. Write the embedded files')[0], ns)
for name, e in ns['EMBED'].items():
    raw = gzip.decompress(base64.b64decode(''.join(e['b64']))); ok = hashlib.sha256(raw).hexdigest() == e['sha256']
    bad += (not ok); print(('ok      ' if ok else 'MISMATCH'), 'notebook embeds', name)
ok = ns['EMBED']['diagrag_v4.py']['sha256'] == sha(os.path.join(here, 'kaggle', 'diagrag_v4.py')); bad += (not ok)
print(('ok      ' if ok else 'MISMATCH'), 'embedded v4 equals kaggle/diagrag_v4.py')
for f in glob.glob(os.path.join(here, 'kaggle', '*.ipynb')) + [os.path.join(here, 'DiagRAG_v4_kaggle.ipynb')]:
    for c in json.load(open(f))['cells']:
        if c['cell_type'] == 'code': ast.parse(''.join(c['source']))
print('all notebooks parse')
print('RESULT:', 'ALL OK' if not bad else f'{bad} PROBLEM(S)'); sys.exit(1 if bad else 0)
