#!/bin/bash
# Everything that needs NO GPU, NO Kaggle and NO API key, in order. Takes about 10 minutes (without the optional last step).
#   bash scripts/run_all_no_gpu.sh            # steps 1 to 5b
#   RUN_V5=1 bash scripts/run_all_no_gpu.sh   # also regenerate the v5 judged run on this machine (about 3 hours, resumable)
set -e; cd "$(dirname "$0")/.."
echo "== 1. verify every file, every judged-run code hash, and both Kaggle notebooks"; python verify.py | tail -8
echo "== 2. re-fit the detectors from the shipped episodes and compare with the recorded tables"
for r in judged_cpu_run_v4_seed47 judged_cpu_run_v5_seed49 judged_cpu_run_v6_seed50 judged_cpu_run_v7_seed50; do echo "-- $r (CPU stack; expect 31 of 31)"; python kaggle/reproduce_tables.py kaggle/$r | tail -3 || true; done
echo "-- GPU runs need the Kaggle library versions (requirements_kaggle_gpu.txt); with the CPU versions they show 27-28 of 31:"; for r in judged_gpu_v4_seed48 judged_gpu_v6_seed50; do echo "-- $r"; python kaggle/reproduce_tables.py kaggle/$r | tail -2 || true; done
echo "== 3. the Q03 and C2 gate-flip diagnosis (about 4 minutes)"; python docs/evidence/diagnose_gate_flips.py kaggle /tmp/gate_flips.json | tail -4
echo "== 4. regenerate the all-runs matrix and the dispatch-policy frontier from the judged files"; python docs/evidence/make_matrix_and_frontier.py kaggle /tmp/all_runs.md | head -14
echo "== 5. the benchmark quickstart"; (cd bench && python verify_release.py release_v1 | tail -2 && python quickstart_dev_cv.py release_v1 /tmp/dev_pred.csv | head -1 && python score.py --labels release_v1/labels_dev.jsonl --track1 /tmp/dev_pred.csv | head -6)
echo "== 5b. composed-fault arm (v7): the single-fault regression check from the shipped files, and the simulated QML comparison (about 2 minutes)"; python docs/evidence/v7_regression_check.py kaggle/judged_cpu_run_v6_seed50 kaggle/judged_cpu_run_v7_seed50 /tmp/v7_regression.json | head -3; python docs/evidence/qml_compare.py kaggle/judged_cpu_run_v6_seed50/episodes.jsonl /tmp/qml_result.json --composed kaggle/judged_cpu_run_v7_seed50/composed_features.jsonl --threads 4 2>&1 | grep -E "AUROC|wrote"
if [ "${RUN_V5:-0}" = 1 ]; then echo "== 6. regenerating the v5 judged run (resumable)"; bash scripts/run_stage.sh v5_cpu "${WORK:-$PWD/work_v5}"; fi
echo "ALL DONE"
