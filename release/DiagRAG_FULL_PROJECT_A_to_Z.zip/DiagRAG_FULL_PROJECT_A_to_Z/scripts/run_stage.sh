#!/bin/bash
# Generic resumable runner for any DiagRAG stage script, on any Linux machine (CPU or GPU).
# Usage:  bash scripts/run_stage.sh <PRESET> [workdir]
# Presets reproduce the exact settings recorded in each judged run's protocol file:
#   v5_cpu        kaggle/diagrag_v5.py   seed 49, N_HARD 100, MAX_ATT 4000   (the v5 judged run, CPU stack; about 3 hours in 25-minute chunks)
#   v4_cpu        kaggle/diagrag_v4.py   seed 47, N_HARD 50,  MAX_ATT 2500   (about 1.5 hours)
#   fiqa_cpu      kaggle/diagrag_port2.py  DATASET=fiqa,    seed 9
#   scifact_cpu   kaggle/diagrag_port2.py  DATASET=scifact, seed 8
#   langchain2    kaggle/diagrag_langchain2.py  seed 11
#   smoke         kaggle/diagrag_v5.py with tiny settings (a code-path check only; its numbers mean nothing)
# State is kept in <workdir>/diagrag_out/checkpoint.pkl; re-running the same command resumes. The script downloads and SHA-256-checks its own data (internet needed).
# Set TORCH_THREADS to the number of CPU cores. Set CHUNK=0 to run without a time budget (one long run) on a machine with no command time limit.
set -u
PRESET="${1:-}"; HERE="$(cd "$(dirname "$0")/.." && pwd)"; WORK="${2:-$PWD/diagrag_work_$PRESET}"; mkdir -p "$WORK"; CHUNK="${CHUNK:-1400}"
export DIAGRAG_WORK="$WORK" TORCH_THREADS="${TORCH_THREADS:-$(nproc)}" TIME_BUDGET="$CHUNK"
CPU_RERANK="RERANKER=cross-encoder/ms-marco-MiniLM-L-6-v2 CE_MAXLEN=256"
case "$PRESET" in
  v5_cpu)      SCRIPT=kaggle/diagrag_v5.py;          ENVV="SEED=49 N_BASE_ESCI=2400 N_PRDC=528 N_HARD=100 MAX_ATT=4000 N_HARM=20 $CPU_RERANK"; MARK="done. outputs";;
  v4_cpu)      SCRIPT=kaggle/diagrag_v4.py;          ENVV="SEED=47 N_BASE_ESCI=2400 N_PRDC=528 N_HARD=50 MAX_ATT=2500 N_HARM=20 $CPU_RERANK"; MARK="done. outputs";;
  fiqa_cpu)    SCRIPT=kaggle/diagrag_port2.py;       ENVV="DATASET=fiqa SEED=9 N_QUERIES=2500 N_HARD=50 MAX_ATT=2500 N_HARM=20 $CPU_RERANK"; MARK="done. outputs";;
  scifact_cpu) SCRIPT=kaggle/diagrag_port2.py;       ENVV="DATASET=scifact SEED=8 N_QUERIES=2500 N_HARD=50 MAX_ATT=2500 N_HARM=20 $CPU_RERANK"; MARK="done. outputs";;
  langchain2)  SCRIPT=kaggle/diagrag_langchain2.py;  ENVV="SEED=11 N_HARD=50 MAX_ATT=2500 N_HARM=20"; MARK="done. outputs";;
  smoke)       SCRIPT=kaggle/diagrag_v5.py;          ENVV="SEED=49 N_BASE_ESCI=60 N_PRDC=20 N_HARD=4 MAX_ATT=30 N_HARM=2 N_CENSUS=300 N_NATQ=80 N_CAL_EXTRA=120 $CPU_RERANK"; MARK="done. outputs";;
  *) sed -n 2,14p "$0"; exit 2;;
esac
[ "$PRESET" = smoke ] && CHUNK=0 && export TIME_BUDGET=0
for i in $(seq 1 60); do
  env $ENVV python -u "$HERE/$SCRIPT" 2>&1 | tee "$WORK/run_$i.log" | grep -v -E "Warning|Loading|Batches" | tail -4
  if grep -q "$MARK" "$WORK/run_$i.log"; then echo "FINISHED. Outputs: $WORK/*out*/  (start with VERDICT.json or the *_VERDICT.json file)"; exit 0; fi
  grep -q "TIME_BUDGET reached" "$WORK/run_$i.log" || { echo "STOPPED WITH AN ERROR - see $WORK/run_$i.log"; exit 1; }
  echo "--- chunk $i finished at its time budget; resuming ---"
done
