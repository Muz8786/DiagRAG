"""Integrity check for the DiagRAG zip. Run:  python verify.py
1) every file in CHECKSUMS.sha256 has the recorded SHA-256;
2) every judged run's protocol records the SHA-256 of the .py file that produced it (the older seed-42 run used code that is not shipped);
3) each Kaggle notebook embeds exactly the code it names (hash re-computed after decoding);
4) the v5 code equals the hash frozen in docs/evidence/v5_protocol.md (its last "frozen v5 hash is now" line), and a v5 judged folder, if present, was produced by it."""
import ast, base64, glob, gzip, hashlib, json, os, re, sys
here = os.path.dirname(os.path.abspath(__file__)); bad = 0
sha = lambda p: hashlib.sha256(open(p, 'rb').read()).hexdigest()
def report(ok, msg):
    global bad; bad += (not ok); print(('ok       ' if ok else 'MISMATCH ') + msg)
for line in open(os.path.join(here, 'CHECKSUMS.sha256'), encoding='utf-8'):
    h, p = line.rstrip('\n').split('  ', 1)
    if not os.path.exists(os.path.join(here, p)) or sha(os.path.join(here, p)) != h: report(False, p)
print('checksums checked')
PAIRS = {'judged_cpu_run_seed43': 'diagrag_core28.py', 'judged_cpu_run_v2_seed44': 'diagrag_v2.py', 'judged_cpu_run_v3_seed45': 'diagrag_v3.py',
         'judged_gpu_v3_seed46': 'diagrag_v3.py', 'judged_cpu_run_v4_seed47': 'diagrag_v4.py', 'judged_gpu_v4_seed48': 'diagrag_v4.py',
         'judged_cpu_run_v5_seed49': 'diagrag_v5.py', 'judged_gpu_v5_seed49': 'diagrag_v5.py', 'judged_port_scifact': 'diagrag_port.py', 'judged_port2_scifact': 'diagrag_port2.py', 'judged_port2_fiqa': 'diagrag_port2.py',
         'judged_langchain_scifact': 'diagrag_langchain.py', 'judged_langchain_v2_scifact': 'diagrag_langchain2.py'}
for folder, py in PAIRS.items():
    d = os.path.join(here, 'kaggle', folder)
    if not os.path.isdir(d):
        print('absent   ' + folder + ('  (no GPU replication of v5 has been run)' if 'v5' in folder else '')); continue
    prot = glob.glob(os.path.join(d, '*PROTOCOL.json')); report(json.load(open(prot[0]))['code_sha256'] == sha(os.path.join(here, 'kaggle', py)), f'{folder} <- {py}')
frozen = re.findall(r'frozen v5 hash is now `([0-9a-f]{64})`', open(os.path.join(here, 'docs', 'evidence', 'v5_protocol.md'), encoding='utf-8').read())
report(bool(frozen) and frozen[-1] == sha(os.path.join(here, 'kaggle', 'diagrag_v5.py')), 'diagrag_v5.py equals the hash frozen in docs/evidence/v5_protocol.md')
for nbname, pyname in (('DiagRAG_v4_kaggle.ipynb', 'diagrag_v4.py'), ('DiagRAG_v5_kaggle.ipynb', 'diagrag_v5.py')):
    nb = json.load(open(os.path.join(here, nbname))); src = '\n'.join(''.join(c['source']) for c in nb['cells'] if c['cell_type'] == 'code'); ns = {}
    exec(src.split('# 3. Write the embedded files')[0], ns)
    for name, e in ns['EMBED'].items():
        raw = gzip.decompress(base64.b64decode(''.join(e['b64']))); report(hashlib.sha256(raw).hexdigest() == e['sha256'], f'{nbname} embeds {name}')
    report(ns['EMBED'][pyname]['sha256'] == sha(os.path.join(here, 'kaggle', pyname)), f'{nbname}: embedded {pyname} equals kaggle/{pyname}')
for f in glob.glob(os.path.join(here, 'kaggle', '*.ipynb')) + [os.path.join(here, 'DiagRAG_v4_kaggle.ipynb'), os.path.join(here, 'DiagRAG_v5_kaggle.ipynb')]:
    for c in json.load(open(f))['cells']:
        if c['cell_type'] == 'code': ast.parse(''.join(c['source']))
print('all notebooks parse')
print('RESULT:', 'ALL OK' if not bad else f'{bad} PROBLEM(S)'); sys.exit(1 if bad else 0)
