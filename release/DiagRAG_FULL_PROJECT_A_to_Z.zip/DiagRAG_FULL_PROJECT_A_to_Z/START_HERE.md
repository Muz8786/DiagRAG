# DiagRAG, full project (A to Z)

1. Read `PROJECT_EXPLAINED.md` (the whole project, in depth, with results, failures and limitations). Section 0 is one page.
2. Run `python verify.py` (10 seconds; expect `RESULT: ALL OK`), then follow `RUN_GUIDE.md` to check or regenerate any result.
3. The execution record is `docs/ROADMAP_V3.md` and `docs/ROADMAP_V4.md`; every judged run is under `kaggle/judged_*`; the pre-registrations and analysis scripts are in `docs/evidence/`.
4. `release/DiagRAG-Bench_v1.0_public_STAGED.zip` is the benchmark package, staged and not released.
