# How to run DiagRAG from A to Z

You do not need to read the whole project to run it. Pick the path that matches what you have.

| You have | Do this | Time |
|---|---|---|
| a laptop, no GPU, no keys | Path 1, then optionally Path 2 | 10 minutes, then about 3 hours |
| a free Kaggle account | Path 3 | 2 to 5 hours (GPU) |
| API keys (Groq, Gemini, or a frontier model) | Path 4 | about 1 hour per arm |

Everything is in this folder. `PROJECT_EXPLAINED.md` explains what the project is and what every result means. Read its section 0 first (one page).

## Path 1. Check the published results without running the pipeline (10 minutes, CPU, no keys)

```bash
python -m venv .venv && . .venv/bin/activate && pip install -r requirements.txt
bash scripts/run_all_no_gpu.sh
```
Steps, in order, and what a good output looks like:
1. `python verify.py` prints `RESULT: ALL OK`. It checks every file's SHA-256, that each judged run's recorded code hash equals the shipped script, that both Kaggle notebooks embed exactly the code they name, and that `diagrag_v5.py` equals the hash frozen in `docs/evidence/v5_protocol.md`.
2. `python kaggle/reproduce_tables.py kaggle/<judged folder>` re-fits every detector from the shipped telemetry and compares with the recorded AUROCs. **Expected:** 31 of 31 for the CPU runs (v4 seed 47, v5 seed 49); 27 of 31 within 0.005 for the Kaggle GPU run (v4 seed 48), because Kaggle's library versions were not recorded. A difference is printed, not hidden.
3. `docs/evidence/diagnose_gate_flips.py` reproduces the Q03 and C2 gate-flip diagnosis.
4. `docs/evidence/make_matrix_and_frontier.py` regenerates the all-runs matrix and the dispatch-policy frontier from the judged files.
5. `bench/` : verify the benchmark release, build a diagnoser on the dev split, score it (AUROC about 0.97).

## Path 2. Regenerate a judged run on your own machine (CPU, resumable)

```bash
bash scripts/run_stage.sh v5_cpu            # the v5 judged run, seed 49: about 3 hours in 25-minute chunks
bash scripts/run_stage.sh v4_cpu            # the v4 CPU run, seed 47: about 1.5 hours
bash scripts/run_stage.sh fiqa_cpu          # the FiQA port, seed 9
bash scripts/run_stage.sh scifact_cpu       # the SciFact port, seed 8
bash scripts/run_stage.sh langchain2        # the LangChain arm (needs: pip install langchain-core langchain-community)
bash scripts/run_stage.sh smoke             # a tiny code-path check of v5 (numbers are meaningless)
```
- Needs internet on the first run: the script downloads its data (corpus, ESCI, Webis-QSpell, and the models) and **checks the exact bytes and SHA-256 of every file before using it**. A mismatch stops the run.
- Disk: about 6 GB measured on the v5 run (models 2.9 GB, downloaded data about 0.7 GB, outputs and checkpoint 0.9 GB, plus the cache directories). RAM: the judged CPU runs used a 30 GB, 8-core machine; the minimum was **not** measured. Set `TORCH_THREADS` to your core count.
- Re-run the same command to resume after an interruption. Results go to `diagrag_work_<preset>/diagrag_out/` : read `VERDICT.json` first, then `REPORT.md`.
- A fresh run will not match to the last digit (library versions differ). Compare **verdicts and intervals**, not digits. A different outcome on the 27-detector rule is possible and is a valid result.
- **The protocol allows one judged v5 run.** The committed result is in `kaggle/judged_cpu_run_v5_seed49/`. Regenerating it here is a reproduction, and does not replace it. Do not change the seed to look for a different verdict.

## Path 3. On Kaggle (GPU)

1. kaggle.com, **Create, New Notebook, File, Import Notebook**, upload `DiagRAG_v5_kaggle.ipynb` (the pre-registered v5 run) or `DiagRAG_v4_kaggle.ipynb` (the judged v4 GPU run).
2. Settings: **Accelerator GPU T4 x1, Internet On.** (A phone-verified account is needed for both.)
3. **Run All** (or Save Version, Save and Run All). No dataset, no key. Results appear in `/kaggle/working/diagrag_out/` : `VERDICT.json`, `REPORT.md`, `GPU_ANALYSIS.json`.
4. If the session stops, run again; it resumes from `diagrag_out/checkpoint.pkl`.

The v5 notebook has not been run on a GPU. A first full run could hit a Kaggle-side problem. Its embedded code is hash-checked against the protocol (`verify.py`).

## Path 4. LLM comparison (needs keys; uses spend if you choose a paid model)

Keys go in **environment variables only**. Never write a key into a file, a notebook or a message.
```bash
export GROQ_API_KEY=...            # free tier: finishes the two Groq arms from their caches
export GEMINI_API_KEYS=key1,key2   # free tier
# optional frontier arm (set a hard spend cap in the provider console FIRST; the script also stops at FRONTIER_MAX_USD, default 15):
export FRONTIER_PROVIDER=openai FRONTIER_MODEL=... FRONTIER_PRICE_IN=... FRONTIER_PRICE_OUT=... FRONTIER_API_KEY=...
python bench/llm_baselines.py llm --out kaggle/judged_llm_baselines --providers groq groq20 gemini frontier --budget 1500
python bench/llm_baselines.py analyze --out kaggle/judged_llm_baselines --providers gemini groq groq20 frontier
```
The plan, prompts and verdict rules are frozen in `docs/evidence/llm_baselines_plan.md` (amendments A1 to A5). Changing a prompt after seeing output is a new arm and needs a new amendment first.

## What each folder is
- `kaggle/` : every script and notebook, and one `judged_*` folder per judged run (protocol with code hash, verdict, tables, report, episodes).
- `docs/evidence/` : the pre-registrations (`v5_protocol.md` with amendments B1 to B8, `llm_baselines_plan.md`), the analysis scripts and their results.
- `bench/` : the benchmark. `scripts/` : the runners. `verify.py` : integrity check.

## If something goes wrong
- `HASH MISMATCH` or a failed `verify.py`: the file was changed or damaged. Re-extract the zip.
- A download fails: re-run; the data checks are idempotent.
- Out of memory: lower `N_BASE_ESCI` (the judged value is 2400) only for a smoke test; a judged reproduction needs the preset values.
- Questions about a number: search `PROJECT_EXPLAINED.md`, then `docs/ROADMAP_V4.md` (the execution record).
