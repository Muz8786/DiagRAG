# DiagRAG-Bench v1.0 (staged package, NOT YET RELEASED)

Telemetry-only diagnosis of retrieval failures in RAG. 2,718 dev episodes with public labels, 2,125 test episodes whose labels are held privately (SHA-256 in `release_v1/MANIFEST.json`).
Start with `QUICKSTART.md` (about 5 minutes, CPU). Read `DATASHEET.md` before you generalise from a score.

**Status.** This package is staged and verified. Its release date and the benchmark name are the owner's decisions. The ShopNova synthetic partition has no licence assigned yet, so **do not redistribute** until one is. Third-party licences: `NOTICE.md` in the main repository.
The faults are injected into an e-commerce retrieval stack by the same authors who wrote the reference diagnoser. The code and documents were written by Claude (Anthropic) under the direction of the repository owner.
