# DiagRAG run package

Open `RUN_GUIDE.md`. Quick start (no GPU, no keys, about 10 minutes):

    python -m venv .venv && . .venv/bin/activate && pip install -r requirements.txt
    bash scripts/run_all_no_gpu.sh

Kaggle GPU: upload `DiagRAG_v5_kaggle.ipynb` (pre-registered v5) or `DiagRAG_v4_kaggle.ipynb` (judged v4), GPU T4 x1, Internet On, Run All.
`PROJECT_EXPLAINED.md` explains the project and every result.
