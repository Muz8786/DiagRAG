# DiagRAG, A to Z (one Kaggle notebook + this data zip)
1. Upload this zip as a PRIVATE Kaggle Dataset. Create a notebook, import `DiagRAG_A_to_Z_kaggle.ipynb`, add the dataset as an input, set Internet On, Run All.
2. (LITE edition: there is no data/ or prereq/ folder; stages A to E work as described, stage F downloads its inputs, stage G needs the full zip.) Default flags run the check path (about 15 to 25 minutes, CPU, no key). Switch on `RUN_V6_GPU` (GPU T4) or `RUN_V7_CPU` in cell 2 for the long regenerations.
3. `A_TO_Z_GUIDE.md` explains every stage, every result and every limitation. `PROJECT_EXPLAINED.md` is the full project write-up.
No API key is needed or included. If a `data/` folder exists it is for private use only (`data/DATA_NOTICE.md`).
